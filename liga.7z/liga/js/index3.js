document.addEventListener("DOMContentLoaded", function(event) {
  $(window).on("load", function() {
    getMobileOperatingSystem();
    $(".loader-bg").fadeOut(500);
  });

  $(window).on("resize", function() {
    mobOverfllow();
  });

  $(window).on("load resize", function() {
    fixedLogo();
  });

  setTimeout(function() {
    $(".pop-up").slideDown();
  }, 1500);

  $(".pop-up-btn").click(function() {
    $(".pop-up").slideUp();
  });

  $(".hamburger").click(function() {
    $(this).toggleClass("hamburger-active");
    $(".nav-content").stop(true, false).slideToggle();
    if ($(".hamburger").hasClass("hamburger-active")) {
      $("body").css("overflowY", "hidden");
    } else {
      $("body").css("overflowY", "auto");
    }
  });

  $(".open-rules").click(function() {
    $(".rule-text-container").fadeIn(500);
    $("body").css("overflowY", "hidden");
  });

  $(".close-btn").click(function() {
    $(".rule-text-container").fadeOut(500);
    $("body").css("overflowY", "auto");
  });

  function mobOverfllow() {
    $(".hamburger").removeClass("hamburger-active");
    $(".nav-content").slideUp();
    $("body").css("overflowY", "auto");
  }

  $(".rules").click(function() {
    $(".nav-content").hide();
    $(".hamburger").removeClass("hamburger-active");
    $("body").css("overflowY", "auto");
    $("html, body").animate({
      scrollTop: $(".scroll").offset().top
    }, 500);
  });

  function fixedLogo() {
    var windowW = $(window).width();
    if (windowW > 1920) {
      var x = (windowW - 1920) / 2;
      $(".icon-top").css({ left: x + 20 });
    } else {
      $(".icon-top").css({ left: 20 });
    }
  }

  function getMobileOperatingSystem() {
    var userAgent = navigator.userAgent || navigator.vendor || window.opera;
    var winPhone = /windows phone/i.test(userAgent);
    var ios = /iPad|iPhone|iPod/.test(userAgent) && !window.MSStream;
    var android = /android/i.test(userAgent);

    if (winPhone || ios || android) {
      $('link[href="css/hovers.css"]').prop("disabled", true);
      $("body *").unbind("mouseenter mouseleave");
      $(".registration").click(function() {
        window.open('https://mobile.efbet.com/register');
      });
      $(".bet").click(function() {
        window.open('https://mobile.efbet.com/sports/node/361881.1');
      });
      $(".footer-btn").click(function() {
        window.open('https://liga.efbet.com/');
      });
      $(".winners").click(function() {
        window.open('https://liga.efbet.com/');
      });
      return "Phone Device";
    } else {
      $('link[href="css/hovers.css"]').prop("disabled", false);
      $(".registration").click(function() {
        window.open('https://www.efbet.com/BG/Registration#action=register');
      });
      $(".bet").click(function() {
        window.open('https://www.efbet.com/BG/sports#bo-navigation=282241.1,282242.1,361881.1&action=market-group-list');
      });
      $(".winners").click(function() {
        window.open('https://liga.efbet.com/');
      });
      $(".footer-btn").click(function() {
        window.open('https://liga.efbet.com/');
      });
      return "Desktop";
    }
  };
});